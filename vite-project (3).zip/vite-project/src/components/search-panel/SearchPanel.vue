<template>
   <input type="text" class="form-control search-input" placeholder="Kinolarni qidirish"/>
</template>

<script>
export default {
    
}
</script>

<style scoped>
    .search-input {
        margin-bottom: 1rem;
        padding: 1.5rem;
        background-color: #fcf5faf5;
        border-radius: 4px;
        box-shadow: 15px 15px 15px rgba(51, 50, 50, 0.15);
    }
</style>