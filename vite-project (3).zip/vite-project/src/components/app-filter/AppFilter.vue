<template>
    <div class="btn-group">
        <button class="btn btn-dark" type="button">Barcha kinolar</button>
        <button class="btn btn-outline-dark" type="button">Mashhur kinolar</button>
        <button class="btn btn-outline-dark" type="button">Eng ko'p ko'rilgan kinolar</button>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
    
</style>