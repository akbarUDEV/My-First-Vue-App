<template>
    <div class="app-info">
        <p class="fs-3 text-uppercase">Barcha kinolar soni: 0</p>
        <p class="fs-4 text-uppercase">Ko'rilgan kinolar soni: 0</p>
    </div>
</template>


<script>

</script>


<style scoped>
.app-info{
    padding: 1.5rem;
    background-color: #fcf5faf5;
    border-radius: 4px;
    box-shadow: 15px 15px 15px rgba(51, 50, 50, 0.15);
}
</style>