<template>
    <div class="movie-add-form">
        <h3>Add new film</h3>
        <form class="add-form d-flex">
            <input type="text" class="form-control new-movie-label" placeholder="Qanday kino?"/>
            <input type="text" class="form-control new-movie-label" placeholder="Nechchi marotaba ko'rilgan?"/>
            <button class="btn btn-outline-dark" type="submit">Qo'shish</button>
        </form>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
    .movie-add-form{
        margin-top: 2rem;
  padding: 1.5rem;
  background-color: #fcf5faf5;
  border-radius: 4px;
  box-shadow: 15px 15px 15px rgba(51, 50, 50, 0.15);
    }
</style>