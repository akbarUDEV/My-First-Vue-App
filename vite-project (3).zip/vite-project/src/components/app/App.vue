<template>
  <div class="app font-monospace">
   <div class="content">
    <AppInfo/>
    <div class="search-panel">
      <SearchPanel/>
      <AppFilter/>
    </div>
    <MovieList/>
    <MovieAddForm/>
   </div>
 </div>
</template>


<script>
import AppInfo from "@/components/app-info/Appinfo.vue"
import SearchPanel from "@/components/search-panel/SearchPanel.vue"
import AppFilter from "@/components/app-filter/AppFilter.vue"
import MovieList from "@/components/movie-list/MovieList.vue"
import MovieAddForm from "@/components/movie-add-form/MovieAddForm.vue"
 export default {
   components:{
    AppInfo,
    SearchPanel,
    AppFilter,
    MovieList,
    MovieAddForm,
   },
 }
</script>

<style>
.app{
  height: 100vh;
  color:rgb(0, 0, 0);
}
.content{
  width: 1000px;
  min-height: 700px;
  background-color: rgb(255, 255, 255);
  margin:0 auto;
  padding: 5rem 0;
}
.search-panel{
  margin-top: 2rem;
  padding: 1.5rem;
  background-color: #fcf5faf5;
  border-radius: 4px;
  box-shadow: 15px 15px 15px rgba(51, 50, 50, 0.15);
}
</style>